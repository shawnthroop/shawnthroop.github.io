# Spearmint

A clean, beautiful, and lightly accented theme for Mint designed by Shawn Throop. Availible on thecarton.net

---

## Installation

1. Upload the /spearmint/ directory and its contents to /mint/styles/.

2. Login to your Mint installation and in the Preferences use the style drop-down under Display to select Spearmint.

3. Click "Done" to save your choice.


## Extras

If you are a user of Shaun Inman's Secret Crush Pepper than you will be familiar with the magnifying glass icon that appears in Mint when it is enabled. Sadly this icon isn't retina ready. I've included my own home-made replacement icon in the Spearmint folder. To use it:

1. Rename the image mint/styles/vanilla_mint/images/icon-search.png to something different.
2. Move the Retina display compatible icon-search.png from /spearmint/images to mint/styles/vanilla_mint/images. 

Note: this will replace the icon across all themes because it is embedded into the HTML. 


## Contact

If you have trouble with this style please contact me, my details are here - thecarton.net/contact

---
Theme based off of styles found in the Clearmint theme - http://www.devlounge.net/extras/clearmint
Mint - http://www.haveamint.com


Version 1.04 - May 29th, 2013